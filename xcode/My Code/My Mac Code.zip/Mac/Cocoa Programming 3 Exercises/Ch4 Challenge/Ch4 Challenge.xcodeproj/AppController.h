//
//  AppController.h
//  Ch4 Challenge
//
//  Created by Antony Harris on 29/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <cocoa/Cocoa.h>


@interface AppController : NSObject {
    IBOutlet NSTextField *textField;
    IBOutlet NSTextField *textLabel;
}

-(IBAction)countCharacters:(id)sender;

@end
