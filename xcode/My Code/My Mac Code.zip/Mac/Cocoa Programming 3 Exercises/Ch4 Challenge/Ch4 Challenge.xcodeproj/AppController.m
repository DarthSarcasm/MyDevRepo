//
//  AppController.m
//  Ch4 Challenge
//
//  Created by Antony Harris on 29/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AppController.h"


@implementation AppController

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
        
        // Nothing to do :)
    }
    
    return self;
}

-(IBAction)countCharacters:(id)sender
{
    // Extract the contents of textField to do the calculation
    NSLog(@"Counting begins - extracting textField");
    NSString *string = [textField stringValue];
            
    // Set the label - stringWithFormat is an NSString constructor that returns an auto released NSString object.
    // That is then used in setStringValue for textLabel - simples!
    NSLog(@"Setting the UI Label for %@", string);
    [textLabel setStringValue:[NSString stringWithFormat:@"'%@' has %ld characters.", string, [string length]]];

}

- (void)awakeFromNib
{
    // Puts a default values in the label field, so it doesn't look pants at start up.
	[textLabel setStringValue:@"???"];
}

- (void)dealloc
{
    [super dealloc];
}

@end
