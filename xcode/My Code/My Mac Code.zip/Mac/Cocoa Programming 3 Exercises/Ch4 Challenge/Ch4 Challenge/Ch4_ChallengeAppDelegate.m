//
//  Ch4_ChallengeAppDelegate.m
//  Ch4 Challenge
//
//  Created by Antony Harris on 29/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Ch4_ChallengeAppDelegate.h"

@implementation Ch4_ChallengeAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
