//
//  Ch4_ChallengeTests.h
//  Ch4 ChallengeTests
//
//  Created by Antony Harris on 29/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface Ch4_ChallengeTests : SenTestCase {
@private
    
}

@end
