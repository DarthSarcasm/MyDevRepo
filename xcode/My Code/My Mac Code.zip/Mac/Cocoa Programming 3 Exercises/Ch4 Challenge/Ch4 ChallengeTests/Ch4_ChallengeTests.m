//
//  Ch4_ChallengeTests.m
//  Ch4 ChallengeTests
//
//  Created by Antony Harris on 29/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Ch4_ChallengeTests.h"


@implementation Ch4_ChallengeTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Ch4 ChallengeTests");
}

@end
