//
//  AppController.h
//  CoinFlipper
//
//  Created by Tony Harris on 29/12/2010.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

// Appcontroller for the app, handles the messages to/from the interface and (in this case) runs the flipping.

@interface AppController : NSObject {
	// Outlets for the items in the interface - stuff to connect the interface to.
	IBOutlet NSTextField *headsNumField;
	IBOutlet NSTextField *tailsNumField;
	IBOutlet NSTextField *flipNumField;
	IBOutlet NSTextField *currNumField;
	
	IBOutlet NSLevelIndicator *headsLevel;
	IBOutlet NSLevelIndicator *tailsLevel;

	IBOutlet NSButton *startButton;

	// And some variables to store stuff in!
	int headsNum;
	int tailsNum;
	int flipNum;
	int currNum;
	bool isFlipping;
}

// Action methods (like C-functions) to do STUFF!
- (IBAction) startFlipping:(id)sender;
- (void) runFlipper;

@end
