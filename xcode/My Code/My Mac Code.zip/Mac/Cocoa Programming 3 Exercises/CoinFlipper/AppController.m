//
//  AppController.m
//  CoinFlipper
//
//  Created by Tony Harris on 29/12/2010.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "AppController.h"


@implementation AppController

- (void)awakeFromNib
{
	// Override std NSObject method to set startup state.
	isFlipping = FALSE;
}

- (IBAction) startFlipping:(id)sender
{
	// This function changes the button title and isFlipping when the button is clicked.
	if (isFlipping == FALSE)	{
		[startButton setTitle:@"Stop"];
		isFlipping = TRUE;
		// Below version runs the Flip as a spearate thread and allows the interface to update correctly.
		[NSThread detachNewThreadSelector:@selector(runFlipper) toTarget:self withObject:nil];
	}	else	{
		[startButton setTitle:@"Start"];
		isFlipping = FALSE;
	}
    
}

- (void) runFlipper
{
	// Memory Pool management added for threaded running...
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	// Like C++, Obj-C can declare variables ANYWHERE in the program...
	srandom(time(NULL));
	int side;
	headsNum=0;
	tailsNum=0;
	currNum=0;
	flipNum = [flipNumField intValue];
    
	// Time to flip!
	while ((isFlipping == TRUE) && (currNum < flipNum))	{
		side = random() % 2; // Modulo returns whole numbers (0 -> x-1). So in this case 0 or 1.
		if (side == 0)
			headsNum++;
		else
			tailsNum++;
        
		// Write the current values back to the interface objects.
		[tailsNumField setIntValue:tailsNum];
		[headsNumField setIntValue:headsNum];
		[headsLevel setMaxValue:currNum];
		[tailsLevel setMaxValue:currNum];
		[headsLevel setIntValue:headsNum];
		[tailsLevel setIntValue:tailsNum];
		currNum++;
		[currNumField setIntValue:currNum]; 
	}
	// Reset to start
	[startButton setTitle:@"Start"];
	isFlipping = FALSE;
	
	// Memory pool drain
	[pool drain];
}

@end
