//
//  CoinFlipperAppDelegate.m
//  CoinFlipper
//
//  Created by Tony Harris on 29/12/2010.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "CoinFlipperAppDelegate.h"

@implementation CoinFlipperAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

@end
