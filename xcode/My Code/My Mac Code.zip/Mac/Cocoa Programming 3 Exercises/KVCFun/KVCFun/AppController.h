//
//  AppController.h
//  KVCFun
//
//  Created by Antony Harris on 29/10/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//



@interface AppController : NSObject
{
    int fido;
}

// Removed fido and setFido methods, replaced with a @property.
@property(readwrite, assign) int fido;
-(IBAction)incrementFido:(id)sender;

@end