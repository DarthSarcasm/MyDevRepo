//
//  AppController.m
//  KVCFun
//
//  Created by Antony Harris on 29/10/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AppController.h"

@implementation AppController

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
        [self setValue:[NSNumber numberWithInt:5] forKey:@"fido"];
        NSNumber *n=[self valueForKey:@"fido"];
        NSLog(@"fido=%@", n);
    }
    
    return self;
}

// Replaced fido and setFido method code with synthesize (same functionality, no logging)
@synthesize fido;

-(IBAction)incrementFido:(id)sender
{
    // incrementing done more cleanly, using fido's own accessor method
    [self setFido:[self fido] + 1];
}

@end
