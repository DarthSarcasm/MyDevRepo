//
//  KVCFunTests.m
//  KVCFunTests
//
//  Created by Antony Harris on 29/10/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "KVCFunTests.h"

@implementation KVCFunTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in KVCFunTests");
}

@end
