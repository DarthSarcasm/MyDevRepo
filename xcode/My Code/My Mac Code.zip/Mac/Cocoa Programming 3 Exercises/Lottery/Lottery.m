#import <Foundation/Foundation.h>

int main (int argc, const char * argv[]) {
	// Memory handling init
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	// Start by initialising an array
	NSMutableArray *array;
	array = [[NSMutableArray alloc] init]; // <- Standard way to initialise the instance of the class, allocate memory and init
	
	// Fill the array with 10 numbers
	int i;
	for (i = 0; i < 10; i++)	{
		NSNumber *newNumber = [[NSNumber alloc] initWithInt:(i * 3)]; // <- Standard init with variable.
		[array addObject:newNumber];
	}
	
	// Show the contents of the array
	for (i = 0; i < 10; i++)	{
		NSNumber *numberToPrint = [array objectAtIndex:i];
		NSLog(@"The Number at Index %d is %@", i, numberToPrint); // Note: Special @ symbol for handling NSString and the %@ to display an Object
	}
	
	// Memory release
	[pool drain];
    return 0;
}
