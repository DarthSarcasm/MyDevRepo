//
//  LotteryEntry.m
//  Lottery
//
//  Created by Antony Harris on 27/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LotteryEntry.h"


@implementation LotteryEntry

- (void)prepareRandomNumbers
{
	firstNumber = random() % 100 + 1;
	secondNumber = random() % 100 + 1;
}
- (void)setEntryDate:(NSCalendarDate *)date
{
	entryDate = date;
	[date setCalendarFormat:@"%b %d %Y"];
}
- (NSCalendarDate *)entryDate
{
	return entryDate;
}
- (int)firstNumber
{
	return firstNumber;
}
- (int)secondNumber
{
	return secondNumber;
}
- (NSString *)description
{
    NSString *result;
    result = [[NSString alloc]initWithFormat:@"%@ = %d and %d", [entryDate descriptionWithCalendarFormat:@"%b %d %Y"], firstNumber, secondNumber];
    return result;
}

@end
