//
//  Person.h
//  RaiseMan
//
//  Created by Antony Harris on 29/10/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

// Person = model class, so no need to import cocoa.h. Importing foundation.h is cleaner, smaller and makes it reusable in a command line tool
#import <Foundation/Foundation.h>

@interface Person : NSObject
{
    NSString *personName;
    float expectedRaise;
}

@property(readwrite, copy) NSString *personName;
@property(readwrite) float expectedRaise;

@end
