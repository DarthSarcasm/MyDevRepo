//
//  Person.m
//  RaiseMan
//
//  Created by Antony Harris on 29/10/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Person.h"

@implementation Person

- (id)init
{
    self = [super init];
    if (self) {
        expectedRaise = 5.0;
        personName = @"New Person";
    }
    
    return self;
}

// Overriding dealloc to explicitly call release for personName
-(void)dealloc
{
    [personName release];
    [super dealloc];
}

// Overriding setNilValueForKey to prevent nil values throwing an exception
-(void)setNilValueForKey:(NSString *)key
{
    if ([key isEqual:@"expectedRaise"]) {
        [self setExpectedRaise:0.0];
    } else  {
        [super setNilValueForKey:key];
    }
}

@synthesize personName;
@synthesize expectedRaise;

@end
