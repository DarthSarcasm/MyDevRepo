//
//  MyDocument.h
//  RaiseMan
//
//  Created by Antony Harris on 29/10/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

// Declare the employees array
@interface MyDocument : NSDocument {
    NSMutableArray *employees;
}

-(void)setEmployees:(NSMutableArray *)a;

@end
