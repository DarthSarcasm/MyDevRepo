//
//  RaiseManTests.h
//  RaiseManTests
//
//  Created by Antony Harris on 29/10/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface RaiseManTests : SenTestCase

@end
