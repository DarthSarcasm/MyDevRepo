//
//  RandomAppDelegate.h
//  Random
//
//  Created by Antony Harris on 17/10/2012.
//  Copyright (c) 2012 Antony Harris. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface RandomAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
