//
//  RandomAppDelegate.m
//  Random
//
//  Created by Antony Harris on 17/10/2012.
//  Copyright (c) 2012 Antony Harris. All rights reserved.
//

#import "RandomAppDelegate.h"

@implementation RandomAppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
