//
//  main.m
//  Random
//
//  Created by Antony Harris on 17/10/2012.
//  Copyright (c) 2012 Antony Harris. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
