#import <Foundation/Foundation.h>

// NOTE: At no point in this code is a variable type defined for the user input. 
// The variable types are defined at run time when the NSArray and NSCountedSet are instantiated.

int main (int argc, const char * argv[]) {
	// Standard memory management - part of the foundation template
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	// Takes all command line arguments and puts them in an NSArray ready for processing
	// Then create a new NSCountedSet, initialised with the NSArray	
	NSArray *args = [[NSProcessInfo processInfo] arguments];	
	NSCountedSet *cset = [[NSCountedSet alloc] initWithArray:args];
	
	// Create the sorted array from cset
	NSArray *sorted_args = [[cset allObjects]
							sortedArrayUsingSelector:@selector(compare:)];
	
	// Now set up an NSEnumerator so we can easily cycle through the objects in the sorted array in order
	NSEnumerator *enm = [sorted_args objectEnumerator];
	
	// Use id dynamic variable to cast to string for display purposes.
	id word; 
	while (word = [enm nextObject]) {
		printf("%s\n", [word UTF8String]); // <- Tell word to behave like a string? Like a c-based cast()
	}
	
	// Release the memory for the NSCountedSet
	[cset release];
	
	// Standard memory release and program exit - part of the foundation template
	[pool release];
	return 0;
}
