//
//  AppController.h
//  SpeakLine
//
//  Created by Antony Harris on 29/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <cocoa/Cocoa.h>


@interface AppController : NSObject {
    IBOutlet NSTextField *textField;
    IBOutlet NSButton *stopButton;
    IBOutlet NSButton *startButton;
    IBOutlet NSTableView *tableView;
    NSArray *voiceList;
    
    NSSpeechSynthesizer *speechSynth;
}

-(IBAction)sayIt:(id)sender;
-(IBAction)stopIt:(id)sender;

@end
