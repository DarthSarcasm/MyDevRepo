//
//  AppController.m
//  SpeakLine
//
//  Created by Antony Harris on 29/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AppController.h"


@implementation AppController

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
        
        // Logs can help the beginner understand what is happening and hunt down bugs.
        NSLog(@"init");
        
        // Create an instance of NSSpeechSynthesizer with the defualt voice
        speechSynth = [[NSSpeechSynthesizer alloc] initWithVoice:nil];
        // Set the AppController as the delegate of the speech synthesizer. XCode 4 doesn't like this, not sure why.
        [speechSynth setDelegate:self];
        // Add a list of available voices
        voiceList = [[NSSpeechSynthesizer availableVoices] retain];
    }
    
    return self;
}

- (IBAction)sayIt:(id)sender
{
    NSString *string = [textField stringValue];
    
    // Is the string zero length?
    if ([string length] == 0)   {
        NSLog(@"string from %@ is zero length", textField);
        return;
    }
    // Speak the string.
    [speechSynth startSpeakingString:string];
    NSLog(@"Have started to speak %@", string);
    // Toggle the enable/disable of the action buttons
    [stopButton setEnabled:YES];
    [startButton setEnabled:NO];
    // Toggle the tableview
    [tableView setEnabled:NO];
}

- (IBAction)stopIt:(id)sender
{
    NSLog(@"Stopping");
    // Stop speaking.
    [speechSynth stopSpeaking];
}

- (void)speechSynthesizer:(NSSpeechSynthesizer *)sender didFinishSpeaking:(BOOL)complete
{
    NSLog(@"complete = %d", complete);
    // Set the button states back to default.
    [stopButton setEnabled:NO];
    [startButton setEnabled:YES];
    // And toggle the tableview again
    [tableView setEnabled:YES];
}

- (int)numberOfRowsInTableView:(NSTableView *)tv
{
    // This function returns the number of voices - needed for NSTableView
    return [voiceList count];
}

- (id)tableView:(NSTableView *)tv objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    // Get the complete list of Voices for the TableView
    NSString *v = [voiceList objectAtIndex:row];
    // return v; Would give the LOOOONG name
    NSDictionary *dict = [NSSpeechSynthesizer attributesForVoice:v];
    return [dict objectForKey:NSVoiceName];
}

- (void)tableViewSelectionDidChange:(NSNotification *)notification
{
    // Time to tell the speechsynth that the selected voice has changed
    int row = [tableView selectedRow];
    if (row == -1)  {
        return;
    }
    NSString *selectedVoice = [voiceList objectAtIndex:row];
    [speechSynth setVoice:selectedVoice];
    NSLog(@"new voice = %@", selectedVoice);
}

-(void)awakeFromNib
{
    // Select the default voice in the TableView once the application starts
    NSString *defaultVoice = [NSSpeechSynthesizer defaultVoice];
    int defaultRow = [voiceList indexOfObject:defaultVoice];
    [tableView selectRowIndexes:[NSIndexSet indexSetWithIndex:defaultRow] byExtendingSelection:NO];
    [tableView scrollRowToVisible:defaultRow];
}

- (void)dealloc
{
    [super dealloc];
}

@end
