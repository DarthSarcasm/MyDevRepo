//
//  SpeakLineAppDelegate.m
//  SpeakLine
//
//  Created by Antony Harris on 29/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SpeakLineAppDelegate.h"

@implementation SpeakLineAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
