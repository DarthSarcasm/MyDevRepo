//
//  SpeakLineTests.h
//  SpeakLineTests
//
//  Created by Antony Harris on 29/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface SpeakLineTests : SenTestCase {
@private
    
}

@end
