//
//  Asset.m
//  BMITime
//
//  Created by Antony Harris on 19/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Asset.h"

@implementation Asset

@synthesize label, resaleValue;

// Following two methods are overridden from NSObject - no need to prototype in Asset.h
- (NSString *)description
{
    return [NSString stringWithFormat:@"<%@: $%d >", [self label], [self resaleValue]];
}

- (void)dealloc
{
    NSLog(@"deallocating %@", self);
}
@end
