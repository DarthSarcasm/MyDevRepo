//
//  Employee.h
//  BMITime
//
//  Created by Antony Harris on 19/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Person.h"
@class Asset; // Added to stop the compiler from panicing, instead of Asset.h.

@interface Employee : Person
{
    int employeeID;
    NSMutableArray *assets;
}
@property int employeeID;

// Added to manage the Asset array
- (void)addAssetsObject:(Asset *)a;
- (unsigned int)valueOfAssets;

@end
