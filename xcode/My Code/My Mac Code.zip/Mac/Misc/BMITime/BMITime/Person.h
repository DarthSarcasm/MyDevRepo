//
//  Person.h
//  BMITime
//
//  Created by Antony Harris on 19/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

// This class inherits variables & methods from NSObject.
@interface Person : NSObject
{
    // It has two instance variables
    float heightInMeters;
    int weightInKilos;
}

// You can use @property for default setters & getters
@property float heightInMeters;
@property int weightInKilos;

// This method calculates the Body Mass Index.
- (float)bodyMassIndex;
@end
