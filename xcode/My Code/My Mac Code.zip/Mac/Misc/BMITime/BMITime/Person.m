//
//  Person.m
//  BMITime
//
//  Created by Antony Harris on 19/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Person.h"

@implementation Person

// You can also use @sythesize to generate default accessors, if you use @property in the header
@synthesize heightInMeters, weightInKilos;

- (float)bodyMassIndex
{
    // Updated to use self for accessor method calls.
    float h = [self heightInMeters];
    return [self weightInKilos] / (h * h);
}

@end
