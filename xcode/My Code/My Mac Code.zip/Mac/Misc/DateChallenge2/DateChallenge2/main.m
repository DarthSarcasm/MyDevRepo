//
//  main.m
//  DateChallenge2
//
//  Created by Tony Harris on 13/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // Get an NSDate for now
        NSDate *now = [NSDate date];
            
        // Get an NSDate from 25/09/1973 (using code from the book)
        NSDateComponents *comps = [[NSDateComponents alloc] init]; // Std empty initialiser.
        // Initialise comps
        [comps setYear:1973];
        [comps setMonth:9];
        [comps setDay:25];
        [comps setHour:5];
        [comps setMinute:30];
        [comps setSecond:0];
            
        NSCalendar *g = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];    
        NSDate *dateOfBirth = [g dateFromComponents:comps];
            
        // Calculate the time between then and now.
        double secondsDifference = [now timeIntervalSinceDate:dateOfBirth];
            
        NSLog(@"You have been alive for %f seconds!", secondsDifference);
        
    }
    return 0;
}

