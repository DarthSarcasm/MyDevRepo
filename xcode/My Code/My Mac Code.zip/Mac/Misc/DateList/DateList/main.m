//
//  main.m
//  DateList
//
//  Created by Tony Harris on 17/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // Create three NSDate objects - now, tomorrow and yesterday.
        NSDate *now = [NSDate date];
        NSDate *tomorrow = [now dateByAddingTimeInterval:24.0 * 60.0 * 60.0];
        NSDate *yesterday = [now dateByAddingTimeInterval:-24.0 * 60.0 * 60.0];
 
        // Create an empty Array - NSMutableArray
        NSMutableArray *dateList = [NSMutableArray array];
        
        // Add the dates to the Array
        [dateList addObject:now];
        [dateList addObject:tomorrow];
        
        // Now, we can add yesterday to the front of the Array, rather than at the end!
        [dateList insertObject:yesterday atIndex:0];
        
        for (NSDate *d in dateList)
            NSLog(@"Here is a date: %@", d);
        
        // Remove yesterday - why not!
        [dateList removeObjectAtIndex:0];
        
        // Check it.
        NSLog(@"Now the first date is: %@", [dateList objectAtIndex:0]);
        
     }
    return 0;
}

