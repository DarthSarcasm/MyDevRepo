//
//  main.c
//  Numbers
//
//  Created by Antony Harris on 05/02/2012.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

int main (int argc, const char * argv[])
{

    // Handling ints - %d
    int x = 255;
    printf("x is %d.\n", x);
    printf("In Octal, x is %o.\n", x);
    printf("In hexadecimal, x is %x.\n", x);
    
    // Handling longs - add l
    long z = 255;
    printf("z is %ld.\n", z);
    printf("In Octal, z is %lo.\n", z);
    printf("In hexadecimal, z is %lx.\n", z);
    
    // Handling unsigned decimal - %o
    unsigned long y = 255;
    printf("y is %lu.\n", y);
    
    // Octal and Hex already assume unsigned, no change.
    printf("In Octal, y is %lo.\n", y);
    printf("In hexadecimal, y is %lx.\n", y);
    
    // Operations follow standard preference
    printf("3 * 3 + 5 * 2 = %d\n", 3 * 3 + 5 * 2);
    // Integer divisional mullarkeys!
    printf("11 / 3 = %d\n", 11 / 3);
    // Using remainders
    printf("11 / 3 = %d remainder of %d.\n", 11 / 3, 11 % 3);
    
    // Want the full response - time to cast to float and use %f
    printf("11 / 3 = %f\n", 11 / (float)3);
    
    // And finally, use of abs and labs.
    x = -5;
    z = 100;
    printf("The absolute value of x is %d\n", abs(x));
    printf("The absolute value of z is %ld\n", labs(z));
    
    return 0;
}

