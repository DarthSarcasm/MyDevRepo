//
//  ForeignStockHolding.m
//  Stocks
//
//  Created by Antony Harris on 19/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ForeignStockHolding.h"

@implementation ForeignStockHolding

@synthesize conversionRate;

- (float)costInDollars
{
    float cRate = [self conversionRate];
    return [super costInDollars] * cRate;
}

- (float)valueInDollars
{
    float cRate = [self conversionRate];
    return [super valueInDollars] * cRate;
}

@end
