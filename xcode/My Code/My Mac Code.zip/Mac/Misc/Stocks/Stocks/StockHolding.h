//
//  StockHolding.h
//  Stocks
//
//  Created by Antony Harris on 19/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StockHolding : NSObject
{
    float purchaseSharePrice;
    float currentSharePrice;
    int numberOfShares;
}

@property float purchaseSharePrice, currentSharePrice;
@property int numberofShares;

- (float)costInDollars;
- (float)valueInDollars;

@end
