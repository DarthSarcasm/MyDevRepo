//
//  StockHolding.m
//  Stocks
//
//  Created by Antony Harris on 19/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "StockHolding.h"

@implementation StockHolding

@synthesize purchaseSharePrice, currentSharePrice, numberofShares;

- (float)costInDollars
{
    int n = [self numberofShares];
    return [self purchaseSharePrice] * n;
}

- (float)valueInDollars
{
    int n = [self numberofShares];
    return [self currentSharePrice] * n;
}

@end
