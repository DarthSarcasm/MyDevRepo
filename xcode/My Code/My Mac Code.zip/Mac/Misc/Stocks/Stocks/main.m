//
//  main.m
//  Stocks
//
//  Created by Antony Harris on 19/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "StockHolding.h"
#import "ForeignStockHolding.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // Time to do the jiggy...
        // First initialise the objects we need.
        
        StockHolding *stock1 = [[StockHolding alloc] init];
        StockHolding *stock2 = [[StockHolding alloc] init];
        ForeignStockHolding *stock3 = [[ForeignStockHolding alloc] init];

        NSMutableArray *stockArray = [NSMutableArray array];

        // First stock into the array
        [stock1 setPurchaseSharePrice:2.3];
        [stock1 setCurrentSharePrice:4.5];
        [stock1 setNumberofShares:40];
        [stockArray addObject:stock1];

        // And the second
        [stock2 setPurchaseSharePrice:12.19];
        [stock2 setCurrentSharePrice:10.56];
        [stock2 setNumberofShares:90];
        [stockArray addObject:stock2];

        // And the third (this one is a ForeignStockHolding)...
        [stock3 setPurchaseSharePrice:45.1];
        [stock3 setCurrentSharePrice:49.51];
        [stock3 setNumberofShares:210];
        [stock3 setConversionRate:0.9];
        [stockArray addObject:stock3];

        // Finally, spedy iteration to print the details - note didn't need to change this as stock3 still counts as a StockHolding object!
        for (StockHolding *s in stockArray)
        {
            NSLog(@"The purchase value of the stock was: %f", [s costInDollars]);
            NSLog(@"The current value of the stock is: %f", [s valueInDollars]);
            NSLog(@"The gain of the stock is: %f", [s valueInDollars] - [s costInDollars]);
        }
    }
    return 0;
}

