//
//  main.m
//  StringHost
//
//  Created by Tony Harris on 17/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // Create a NSHost object for this Mac
        NSHost *thisMac = [NSHost currentHost];
        
        // Get the name of this Mac
        
        NSString *macName = [thisMac localizedName];
        
        // Print the name of this Mac
        
        NSLog(@"The name of this Mac is %@", macName);
        
    }
    return 0;
}

