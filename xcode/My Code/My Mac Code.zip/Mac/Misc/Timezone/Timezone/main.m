//
//  main.m
//  Timezone
//
//  Created by Tony Harris on 17/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSTimeZone *s=[NSTimeZone systemTimeZone];
        
        NSLog(@"THE TIME ZONE IS: %@",s);
        
        
        BOOL val= [s isDaylightSavingTime];
        
        if(val){
            NSLog(@"Day Light is on");
        }
        else {
            NSLog(@"Day Light is off");
        }        
    }
    return 0;
}