//
//  main.c
//  AGoodStart
//
//  Created by Antony Harris on 06/11/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#include <stdio.h>

int main (int argc, const char * argv[])
{
    // Print the beginning of the novel
    printf("It was the best of times. \n");
    printf("It was the worst of times. \n");
    /* Is that actually any good?
        Maybe it needs a rewrite. */
    return 0;
}

