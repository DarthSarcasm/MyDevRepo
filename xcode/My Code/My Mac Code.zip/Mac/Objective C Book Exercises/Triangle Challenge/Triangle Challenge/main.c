//
//  main.c
//  Triangle Challenge
//
//  Created by Antony Harris on 06/11/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#include <stdio.h>

// Extra Points: Using a static global variable!
static float triangleTotal = 180.00;

// The challenge: Write a function that takes two angles and returns a third, adding up to 180 degrees
float remainingAngle(float firstAngle, float secondAngle)
{
    float thirdAngle = triangleTotal - firstAngle - secondAngle;
    return thirdAngle;
}

int main (int argc, const char * argv[])
{
    // Prewritten code
    float angleA = 30.0;
    float angleB = 60.0;
    float angleC = remainingAngle(angleA, angleB);
    printf("The third angle is %.2f\n", angleC);
    return 0;
}

