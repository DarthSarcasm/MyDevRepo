//
//  main.c
//  TwoFloats Challenge
//
//  Created by Antony Harris on 06/11/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#include <stdio.h>

int main (int argc, const char * argv[])
{
    // Challenge!
    
    // Declare two variables of type float
    float firstNumber;
    float secondNumber;
    
    // Assign each with a number with a decimal point
    firstNumber = 3.14;
    secondNumber = 42.91;
    
    // Declare another variable, type double
    double sumNumber;
    
    // Assign in the sum of the two floats
    sumNumber = firstNumber + secondNumber;
    
    // Print the result to the user
    printf("The final number is %f. \n", sumNumber);
    
    return 0;
}

