//
//  MyDocument.h
//  RaiseMan
//
//  Created by Aaron Hillegass on 9/24/07.
//  Copyright __MyCompanyName__ 2007 . All rights reserved.
//


#import <Cocoa/Cocoa.h>

@interface MyDocument : NSDocument
{
	NSMutableArray *employees;
}
@end
