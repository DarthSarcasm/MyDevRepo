//
//  MyDocument.h
//  CarLot
//
//  Created by Aaron Hillegass on 9/13/07.
//  Copyright __MyCompanyName__ 2007 . All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MyDocument : NSPersistentDocument {
}

@end
