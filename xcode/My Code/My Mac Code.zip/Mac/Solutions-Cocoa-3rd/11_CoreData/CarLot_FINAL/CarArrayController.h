//
//  CarArrayController.h
//  CarLot
//
//  Created by Aaron Hillegass on 9/13/07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface CarArrayController : NSArrayController {

}

@end
