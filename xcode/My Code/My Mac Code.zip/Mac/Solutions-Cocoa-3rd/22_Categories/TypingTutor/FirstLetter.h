//
//  FirstLetter.h
//  TypingTutor
//
//  Created by Aaron Hillegass on 10/22/07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (FirstLetter)

- (NSString *)BNR_firstLetter;

@end
