#import <Cocoa/Cocoa.h>

@interface ColorFormatter : NSFormatter {
	NSColorList *colorList;
}

@end
