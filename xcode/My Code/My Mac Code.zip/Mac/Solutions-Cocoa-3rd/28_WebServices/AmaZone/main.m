//
//  main.m
//  AmaZone
//
//  Created by Aaron Hillegass on 6/3/05.
//  Copyright Big Nerd Ranch 2005. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
