//
//  EmployeeViewController.h
//  Departments
//
//  Created by Aaron Hillegass on 10/15/07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import "ManagingViewController.h"


@interface EmployeeViewController : ManagingViewController {

}

@end
