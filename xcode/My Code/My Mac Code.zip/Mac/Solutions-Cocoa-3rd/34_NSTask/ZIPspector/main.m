//
//  main.m
//  ZIPspector
//
//  Created by Aaron Hillegass on 11/5/07.
//  Copyright Big Nerd Ranch 2007 . All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **) argv);
}
