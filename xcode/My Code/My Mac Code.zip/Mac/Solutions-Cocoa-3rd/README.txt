Hello!

In this directory you will find the solutions to the exercises in "Cocoa Programming for Mac OS X, 3rd edition".  You will not find solutions to any of the challenges. (They are challenges, people!)

You are welcome to use this code any way you like.  I make no promises about the suitability for any task, and take no responsibility for any thing bad that happens from its use.

The book was being edited right until the last second, so some of these solutions may not match up exactly with what is in the book.  If you are bothered by this, send me a correction solution (delete the build directory before you mail it) and I'll update this tarball.

In later versions of Xcode, the template projects use XIB files instead of NIB files. From the point of view of the developer, XIB and NIB files are identical.  (XIB files are a readable XML file that gets compiled into an NIB file at compile time.  These solutions use NIB files.

I appreciate that you bought my book, and I hope it proves useful to you.

Best wishes,
Aaron Hillegass
May 8, 2008
