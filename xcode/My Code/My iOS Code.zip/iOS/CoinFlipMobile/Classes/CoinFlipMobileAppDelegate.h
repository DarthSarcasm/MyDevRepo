//
//  CoinFlipMobileAppDelegate.h
//  CoinFlipMobile
//
//  Created by Antony Harris on 06/01/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CoinFlipMobileViewController;

@interface CoinFlipMobileAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    CoinFlipMobileViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet CoinFlipMobileViewController *viewController;

@end

