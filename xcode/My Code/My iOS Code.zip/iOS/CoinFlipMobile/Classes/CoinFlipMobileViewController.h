//
//  CoinFlipMobileViewController.h
//  CoinFlipMobile
//
//  Created by Antony Harris on 06/01/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CoinFlipMobileViewController : UIViewController {
	// Outlets for the items in the interface - stuff to connect the interface to.
	// NOTE: The change from NSTextField to the iOS equivalent, UITextField.
	IBOutlet UITextField *headsNumField;
	IBOutlet UITextField *tailsNumField;
	IBOutlet UITextField *flipNumField;
	IBOutlet UITextField *currNumField;
	
	IBOutlet UIActivityIndicatorView *flipIndicator;
	
	IBOutlet UIButton *startButton;

	// And some variables to store stuff in!
	int headsNum;
	int tailsNum;
	int flipNum;
	int currNum;
	bool isFlipping;	
}

// Action methods (like C-functions) to do STUFF!
- (IBAction) startFlipping:(id)sender;
- (void) runFlipper;


@end

