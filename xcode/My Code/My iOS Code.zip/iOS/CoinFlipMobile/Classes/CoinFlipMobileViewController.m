//
//  CoinFlipMobileViewController.m
//  CoinFlipMobile
//
//  Created by Antony Harris on 06/01/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CoinFlipMobileViewController.h"

@implementation CoinFlipMobileViewController

- (IBAction) startFlipping:(id)sender
{
	// This function changes the button title and isFlipping when the button is clicked.
	if (isFlipping == FALSE)	{
		[startButton setTitle:@"Stop" forState:UIControlStateNormal];
		isFlipping = TRUE;
		// Now, send itself a message to run the flip code.
		[self runFlipper]; //- Single threaded run. Fine until BIG flip numbers used, then hangs until finished.
	}	else	{
		[startButton setTitle:@"Start" forState:UIControlStateNormal];
		isFlipping = FALSE;
	}	
}

- (void) runFlipper
{
	// Like C++, Obj-C can declare variables ANYWHERE in the program...
	srandom(time(NULL));
	int side;
	headsNum=0;
	tailsNum=0;
	currNum=0;
	flipNum = [[flipNumField text] intValue];
	
	// Time to flip!
	[flipIndicator startAnimating];
	while ((isFlipping == TRUE) && (currNum < flipNum))	{
		side = random() % 2; // Modulo returns whole numbers (0 -> x-1). So in this case 0 or 1.
		if (side == 0)
			headsNum++;
		else
			tailsNum++;
		
		// Write the current values back to the interface objects.
		[tailsNumField setText:[NSString stringWithFormat:@"%i", tailsNum]];
		[headsNumField setText:[NSString stringWithFormat:@"%i", headsNum]];
		currNum++;
		[currNumField setText:[NSString stringWithFormat:@"%i", currNum]];
	}
	// Reset to start
	[flipIndicator stopAnimating];
	[startButton setTitle:@"Start" forState:UIControlStateNormal];
	isFlipping = FALSE;
}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
