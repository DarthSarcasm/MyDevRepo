//
//  GomezRum.h
//
//
// These materials contain confidential information and
// trade secrets of Compuware Corporation. You shall
// maintain the materials as confidential and shall not
// disclose its contents to any third party except as may
// be required by law or regulation. Use, disclosure,
// or reproduction is prohibited without the prior express
// written permission of Compuware Corporation.
//
// All Compuware products listed within the materials are
// trademarks of Compuware Corporation. All other company
// or product names are trademarks of their respective owners.
//
// Copyright (c) 2011 Compuware Corporation. All rights reserved.
//
//

#import <Foundation/Foundation.h>


/*!
 * @enum RumReturnCode
 * @brief Defines the possible set of return codes for GomezRum methods
 */

typedef enum {
	RumReturnCode_NotInSample		= 0,
	RumReturnCode_InSample			= 1,
	RumReturnCode_InSampleDoubt		= 2,
	RumReturnCode_RumNotInitialized	= -1,
	RumReturnCode_InvalidRange		= -2,
	RumReturnCode_InternalError		= -3,
	RumReturnCode_IntervalNotFound	= -4,
	RumReturnCode_Reserved1			= -9001,
	RumReturnCode_Reserved2			= -9002,
	RumReturnCode_Reserved3			= -9003,
	RumReturnCode_Reserved4			= -9004,
	RumReturnCode_Reserved5			= -9005
	
} RumReturnCode;


/*! @interface GomezRum
 * 
 * The GomezRum interface supports collection and reporting of custom events along with application state and device state information to the Gomez servers 
 */
@interface GomezRum : NSObject {
    
}

/*!
 Initializes Gomez RUM monitoring for the specified Gomez account. This must be invoked once at the very begining of the application within the main() routine of the application. Multiple calls to this method will be ignored.\n
 -applicationId defaults to the AppName\n
 -groupId defaults to nil \n
 -wrate defaults to 1 \n
 -num defaults to 1 \n
 -sessionSuspendMaxTime defaults to 20 minutes \n
 @param	 accountName  The unique Gomez account name	
 @return  Returns one of the following RumReturnCodes indicating the status of the request
 RumReturnCode_RumNotInitialized - Gomez RUM library is uninitialized. Events cannot be collected in this state \n
 RumReturnCode_NotInSample - The application is not in-sample. Events cannot be collected in this state	  \n	
 RumReturnCode_InSampleDoubt - Gomez RUM is in the process of initialization. Events can be collected in this state \n
 RumReturnCode_InSample - Monitoring has been enabled and application is in-sample. Events can be collected in this state\n 
 
 \n
 */
+ (NSInteger)monitor:(NSString *)accountName;

/*!
 Initializes Gomez RUM monitoring for the specified Gomez account and application Id.This must be invoked once at the very begining of the application within the main() routine of the application.. Multiple calls to this method will be ignored.\n
 -groupId defaults to nil \n
 -wrate defaults to 1 \n
 -num defaults to 1 \n
 -sessionSuspendMaxTime defaults to 20 minutes \n
 @param	 accountName  The unique Gomez account name	
 @param	 applicationId  A user defined name for the application	
 @return  Returns one of the following RumReturnCodes indicating the status of the request
 RumReturnCode_RumNotInitialized - Gomez RUM library is uninitialized. Events cannot be collected in this state \n
 RumReturnCode_NotInSample - The application is not in-sample. Events cannot be collected in this state	  \n	
 RumReturnCode_InSampleDoubt - Gomez RUM is in the process of initialization. Events can be collected in this state \n
 RumReturnCode_InSample - Monitoring has been enabled and application is in-sample. Events can be collected in this state\n  
 \n
 */
+ (NSInteger)monitor:(NSString *)accountName 
	   applicationId:(NSString *)applicationId;

/*!
 Initializes Gomez RUM monitoring for the specified Gomez account, application Id and GroupId.This must be invoked once at the very begining of the application within the main() routine of the application.n. Multiple calls to this method will be ignored.\n
 -wrate defaults to 1 \n
 -num defaults to 1 \n
 -sessionSuspendMaxTime defaults to 20 minutes \n
 @param	 accountName  The unique Gomez account name	
 @param	 applicationId  A user defined name for the application	
 @param  groupId  An ID used to group related monitoring events. CUrrently,only a single group is supported
 @return  Returns one of the following RumReturnCodes indicating the status of the request
 RumReturnCode_RumNotInitialized - Gomez RUM library is uninitialized. Events cannot be collected in this state \n
 RumReturnCode_NotInSample - The application is not in-sample. Events cannot be collected in this state	  \n	
 RumReturnCode_InSampleDoubt - Gomez RUM is in the process of initialization. Events can be collected in this state \n
 RumReturnCode_InSample - Monitoring has been enabled and application is in-sample. Events can be collected in this state\n  
 \n
 */
+ (NSInteger)monitor:(NSString *)accountName 
	   applicationId:(NSString *)applicationId
			 groupId:(NSString *)groupId;

/*!
 Initializes Gomez RUM monitoring for the specified Gomez account, application Id, GroupId and wrate.This must be invoked once at the very begining of the application within the main() routine of the application.. Multiple calls to this method will be ignored.\n
 -num defaults to 1 \n
 -sessionSuspendMaxTime defaults to 20 minutes \n
 @param	 accountName  The unique Gomez account name	
 @param	 applicationId  A user defined name for the application	
 @param  groupId  An ID used to group related monitoring events. CUrrently,only a single group is supported
 @param  wrate  A value between 0.1-1.0  used as a multipler in conjunction with sample rate configured via the Gomez portal to determine if the application is in sample or not.
 @return  Returns one of the following RumReturnCodes indicating the status of the request
 RumReturnCode_RumNotInitialized - Gomez RUM library is uninitialized. Events cannot be collected in this state \n
 RumReturnCode_NotInSample - The application is not in-sample. Events cannot be collected in this state	  \n	
 RumReturnCode_InSampleDoubt - Gomez RUM is in the process of initialization. Events can be collected in this state \n
 RumReturnCode_InSample - Monitoring has been enabled and application is in-sample. Events can be collected in this state\n  
 \n
 */
+ (NSInteger)monitor:(NSString *)accountName 
	   applicationId:(NSString *)applicationId
			 groupId:(NSString *)groupId
			   wrate:(float)wrate;

/*!
 Initializes Gomez RUM monitoring for the specified Gomez account, application Id, GroupId , wrate and num.Expected to be invoked once at the very begining of the application within the main() routine of the application. Multiple calls to this method will be ignored.\n
 -sessionSuspendMaxTime defaults to 20 minutes \n
 @param	 accountName  The unique Gomez account name	
 @param	 applicationId  A user defined name for the application	
 @param  groupId  An ID used to group related monitoring events. CUrrently,only a single group is supported
 @param  wrate  A value between 0.1-1.0  used as a multipler in conjunction with sample rate configured via the Gomez portal to determine if the application is in sample or not.
 @num   A non-zero value used to specify the number of events to be cached locally on the device before reporting
 up the events. A value of 1 indicates that an event is reported as soon as it is collected.
 @return  Returns one of the following RumReturnCodes indicating the status of the request
 RumReturnCode_RumNotInitialized - Gomez RUM library is uninitialized. Events cannot be collected in this state \n
 RumReturnCode_NotInSample - The application is not in-sample. Events cannot be collected in this state	  \n	
 RumReturnCode_InSampleDoubt - Gomez RUM is in the process of initialization. Events can be collected in this state \n
 RumReturnCode_InSample - Monitoring has been enabled and application is in-sample. Events can be collected in this state\n  
 \n
 */
+ (NSInteger)monitor:(NSString *)accountName 
	   applicationId:(NSString *)applicationId
			 groupId:(NSString *)groupId
			   wrate:(float)wrate
				 num:(NSUInteger)num;


/*!
 Initializes Gomez RUM monitoring for the specified Gomez account, application Id, GroupId , wrate and num.Expected to be invoked once at the very begining of the application within the main() routine of the application. Multiple calls to this method will be ignored.\n
 @param	 accountName  The unique Gomez account name	
 @param	 applicationId  A user defined name for the application	
 @param  groupId  An ID used to group related monitoring events. CUrrently,only a single group is supported
 @param  wrate  A value between 0.1-1.0  used as a multipler in conjunction with sample rate configured via the Gomez portal to determine if the application is in sample or not.
 @param  num   A non-zero value used to specify the number of events to be cached locally on the device before reporting up the events. A value of 1 indicates that an event is reported as soon as it is collected
 @param sessionSuspendMaxTime Time in sec that indicates the maximum period of app suspension after which the Gomez App session would time out. This applies only on iOS versions 4 and above with multi-tasking support. For versions of iOS that do not support multi-tasking, apps are terminated (not suspended) as soon as they are exited.
 @return  Returns one of the following RumReturnCodes indicating the status of the request
 RumReturnCode_RumNotInitialized - Gomez RUM library is uninitialized. Events cannot be collected in this state \n
 RumReturnCode_NotInSample - The application is not in-sample. Events cannot be collected in this state	  \n	
 RumReturnCode_InSampleDoubt - Gomez RUM is in the process of initialization. Events can be collected in this state \n
 RumReturnCode_InSample - Monitoring has been enabled and application is in-sample. Events can be collected in this state\n 
 \n
 */
+ (NSInteger)monitor:(NSString *)accountName 
	   applicationId:(NSString *)applicationId
			 groupId:(NSString *)groupId
			   wrate:(float)wrate
				 num:(NSUInteger)num
sessionSuspendMaxTime:(NSTimeInterval)sessionSuspendMaxTime;

/*!
 Records an event with specified name.\n
 @param	 eventName  Name of event	
 @return  Returns one of the following RumReturnCodes indicating the status of the request
 RumReturnCode_RumNotInitialized - Gomez RUM library has not completed initialization\n
 RumReturnCode_NotInSample - The application is not in-sample.  As a consequence, events cannot be collected	  \n	
 RumReturnCode_InSample - Named event has been recorded\n 
 RumReturnCode_InSampleDoubt - Gomez RUM is in the process of initialization. Events is recorded. \n
 RumReturnCode_InternalError - An internal error in processing the request. 
 The getLastErrorMsg can be invoked to fetch details on the error condition
 \n
 */
+ (NSInteger)nameEvent:(NSString *)eventName;

/*!
 Records an event to mark the start of an interval.\n
 @param	 eventName  Name of event	
 @return  Returns one of the following RumReturnCodes indicating the status of the request
 RumReturnCode_RumNotInitialized - Gomez RUM library has not completed initialization\n
 RumReturnCode_NotInSample - The application is not in-sample.  As a consequence, events cannot be collected	  \n	
 RumReturnCode_InSample - Named event has been recorded\n 
 RumReturnCode_InSampleDoubt - Gomez RUM is in the process of initialization. Events is recorded. \n
 RumReturnCode_InternalError - An internal error in processing the request. 
 The getLastErrorMsg can be invoked to fetch details on the error condition
 \n
 */
+ (NSInteger)startInterval:(NSString *)eventName;

/*!
 Records an event to mark the end of an interval. An endInterval event must be matched by a corresponding startInterval event\n
 @param	 eventName  Name of event	
 @return  Returns one of the following RumReturnCodes indicating the status of the request
 RumReturnCode_RumNotInitialized - Gomez RUM library has not completed initialization\n
 RumReturnCode_NotInSample - The application is not in-sample.  As a consequence, events cannot be collected	  \n	
 RumReturnCode_InSample - Named event has been recorded\n 
 RumReturnCode_InSampleDoubt - Gomez RUM is in the process of initialization. Events is recorded. \n
 RumReturnCode_IntervalNotFound - Corresponding startInterval event was not recorded \n
 RumReturnCode_InternalError - An internal error in processing the request. 
 The getLastErrorMsg can be invoked to fetch details on the error condition
 \n
 */
+ (NSInteger)endInterval:(NSString *)eventName;


/*!
 Records an event with a specified name and value \n
 @param	 eventName  Name of event	
 @param eventValue An integral value associated with the event
 @return  Returns one of the following RumReturnCodes indicating the status of the request
 RumReturnCode_RumNotInitialized - Gomez RUM library has not completed initialization\n
 RumReturnCode_NotInSample - The application is not in-sample.  As a consequence, events cannot be collected	  \n	
 RumReturnCode_InvalidRange - The value specified is out of permitted range 0-2147483
 RumReturnCode_InSample - Named event has been recorded\n 
 RumReturnCode_InSampleDoubt - Gomez RUM is in the process of initialization. Events is recorded. \n
 RumReturnCode_IntervalNotFound - Corresponding startInterval event was not recorded \n
 RumReturnCode_InternalError - An internal error in processing the request. 
 The getLastErrorMsg can be invoked to fetch details on the error condition
 \n
 */
+ (NSInteger)customValue:(NSString *)eventName 
			  eventValue:(NSInteger)eventValue;

/*!
 Returns if application is currently in sample or not \n
 @param	 None	
 @return  Returns one of the following RumReturnCodes indicating the status of the request
 RumReturnCode_RumNotInitialized - Gomez RUM library is uninitialized. Events cannot be collected in this state \n
 RumReturnCode_NotInSample - The application is not in-sample. Events cannot be collected in this state	  \n	
 RumReturnCode_InSampleDoubt - Gomez RUM is in the process of initialization. Events can be collected in this state \n
 RumReturnCode_InSample - Monitoring has been enabled and application is in-sample. Events can be collected in this state\n 
 */
+ (NSInteger)getInSample;

/*!
 Returns the Gomez account name that was associated with the monitor request\n
 @param	 None	
 @return  Returns the account name. WIll be nil if invoked before a monitor call
 */
+ (NSString *)getAccountName;

/*!
 Returns the applicaton Id that was associated with the monitor request\n
 @param	 None	
 @return  Returns the application Id. Will be nil if invoked before monitor call
 */
+ (NSString *)getApplicationId;

/*!
 Returns the Group Id that was associated with the monitor request\n
 @param	 None	
 @return  Returns the group Id. WIll be nil if invoked before monitor call
 */
+ (NSString *)getGroupId;

/*!
 Returns the sample rate that was associated with the monitor request\n
 @param	 None	
 @return  Returns the wrate value . Will be zero if invoked before monitor call
 */
+ (float)getWRate;

/*!
 Returns the CLLocation object specifying the previously configured GPS coordinates. The Gomez RUM library does not automatically collect any location information. The location information may be specified via the setGpsLocation call\n
 @param	 None	
 @return  Returns the GPS coordinates as a CLLocation object. Will be nil if invoked before a setGpsLocation call
 */
+ (id)getGpsLocation;

/*!
 May be used to record the current GPS location of the user.The Gomez RUM library does not automatically collect any location information. Note that in compliance with privacy laws, the application is responsible for obtaining relevant permissions from the end-user before collecting the GPS coordinates\n
 @param	 None	
 @return Returns one of the following RumReturnCodes indicating the status of the request
 RumReturnCode_RumNotInitialized - Gomez RUM library is uninitialized. Events cannot be collected in this state \n
 RumReturnCode_NotInSample - The application is not in-sample. Events cannot be collected in this state	  \n	
 RumReturnCode_InSampleDoubt - Gomez RUM is in the process of initialization. Events can be collected in this state \n
 RumReturnCode_InSample - Monitoring has been enabled and application is in-sample. Events can be collected in this state\n 
 
 */
+ (NSInteger)setGpsLocation:(id)gpsLocation;

/*!
 Returns the num value associated with the Monitor request\n
 @param	 None	
 @return Returns the num value. Will be default of 1 if invoked before monitor call
 \n 
 */
+ (NSUInteger)getNum;

/*!
 Returns the Gomez application session timeout period in seconds associated with the Monitor request\n
 @param	 None	
 @return Returns the Gomez application session timeout period in minutes. Will be default of 20 if invoked before monitor call
 \n 
 */
+ (NSTimeInterval)getSessionSuspendMaxTime;

/*!
 Can be invoked to obtain the error code associated with the most RumReturnCode_InternalError condition \n
 @param	 None	
 @return Returns the error code associated with the internal error condition. 0 if there is no internal error
 \n 
 */
+ (NSUInteger)getLastErrorCode;

/*!
 Can be invoked to obtain the error message associated with most recent RumReturnCode_InternalError condition\n
 @param	 None	
 @return Returns the error message associated with the internal error condition. Nil if there is no internal error
 \n 
 */
+ (NSString *)getLastErrorMsg;


@end
