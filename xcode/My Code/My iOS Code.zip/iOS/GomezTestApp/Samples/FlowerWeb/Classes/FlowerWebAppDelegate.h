//
//  FlowerWebAppDelegate.h
//  FlowerWeb
//
//  Created by Compuware 1175 on 3/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FlowerWebViewController;

@interface FlowerWebAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    FlowerWebViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet FlowerWebViewController *viewController;

@end

