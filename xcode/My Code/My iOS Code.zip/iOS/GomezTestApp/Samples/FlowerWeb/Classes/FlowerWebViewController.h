//
//  FlowerWebViewController.h
//  FlowerWeb
//
//  Created by Compuware 1175 on 3/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlowerWebViewController : UIViewController {
	IBOutlet UISegmentedControl *colorChoice;
	IBOutlet UIWebView *flowerView;
	IBOutlet UIWebView *flowerDetailView;
}

-(IBAction)getFlower:(id)sender;
-(IBAction)toggleFlowerDetail:(id)sender;

@property (retain,nonatomic) UISegmentedControl *colorChoice;
@property (retain,nonatomic) UIWebView *flowerView;
@property (retain,nonatomic) UIWebView *flowerDetailView;

@end

