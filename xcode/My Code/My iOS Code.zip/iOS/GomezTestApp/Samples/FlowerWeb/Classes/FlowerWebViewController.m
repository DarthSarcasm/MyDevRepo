//
//  FlowerWebViewController.m
//  FlowerWeb
//
//  Created by Compuware 1175 on 3/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FlowerWebViewController.h"
#import "GomezRum.h"
@implementation FlowerWebViewController
@synthesize colorChoice;
@synthesize flowerDetailView;
@synthesize flowerView;

-(IBAction)toggleFlowerDetail:(id)sender {
	flowerDetailView.hidden=![sender isOn];
}

-(IBAction)getFlower:(id)sender {
	NSURL *imageURL;
	NSURL *detailURL;
	NSString *imageURLString;
	NSString *detailURLString;
	NSString *startIntervalString;
	NSString *color;
	int sessionID;
	[GomezRum nameEvent:@"FLWR-Get Img"];
	color=[colorChoice titleForSegmentAtIndex:colorChoice.selectedSegmentIndex];
	startIntervalString=[[NSString alloc] initWithFormat:
						 @"FLWR-Ret %@ img",color];
	[GomezRum startInterval:startIntervalString];
	sessionID=random()%1000;
	[GomezRum customValue:@"FLWR-Web SessionID" eventValue:sessionID];
	if (flowerDetailView.hidden) {
		[GomezRum customValue:@"FLWR-Det Vu Hidden" eventValue:1];
	} else {
		[GomezRum customValue:@"FLWR-Det Vu NHid" eventValue:0];
	}

	
	imageURLString=[[NSString alloc] initWithFormat:
					@"http://www.floraphotographs.com/showrandomiphone.php?color=%@&session=%d"
					,color,sessionID];
	detailURLString=[[NSString alloc] initWithFormat:
					 @"http://www.floraphotographs.com/detailiphone.php?session=%d",sessionID];
	
	imageURL=[[NSURL alloc] initWithString:imageURLString];
	detailURL=[[NSURL alloc] initWithString:detailURLString];
	
	[flowerView loadRequest:[NSURLRequest requestWithURL:imageURL]];
	[flowerDetailView loadRequest:[NSURLRequest requestWithURL:detailURL]];
	
	flowerDetailView.backgroundColor=[UIColor clearColor];
	[GomezRum endInterval:startIntervalString];
	[imageURLString release];
	[detailURLString release];
	[startIntervalString release];
	[imageURL release];
	[detailURL release];
}



/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	flowerDetailView.hidden=YES;
	[self getFlower:nil];
    [super viewDidLoad];
}



/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[colorChoice release];
	[flowerDetailView release];
	[flowerView release];
    [super dealloc];
}

@end
