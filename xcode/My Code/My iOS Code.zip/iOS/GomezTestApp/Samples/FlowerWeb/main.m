//
//  main.m
//  FlowerWeb
//
//  Created by Compuware 1175 on 3/17/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GomezRum.h"

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	[GomezRum monitor:@"FFFFFF" applicationId:@"FlowerWeb" groupId:@"Group1" wrate:1.0f num:2];
	[GomezRum startInterval:@"FLWR-Start"];
	
	[GomezRum nameEvent:@"FLWR-App Launched"];
	
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
