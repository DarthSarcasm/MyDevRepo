//
//  HotCocoaSumAppDelegate.h
//  HotCocoaSum
//
//  Created by Antony Harris on 12/01/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HotCocoaSumViewController;

@interface HotCocoaSumAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    HotCocoaSumViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet HotCocoaSumViewController *viewController;

@end

