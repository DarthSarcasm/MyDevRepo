//
//  HotCocoaSumViewController.h
//  HotCocoaSum
//
//  Created by Antony Harris on 12/01/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HotCocoaSumViewController : UIViewController {
	
	IBOutlet UITextField *num1Field;
	IBOutlet UITextField *num2Field;
	IBOutlet UITextField *sumField;
	
	IBOutlet UIButton	*sumButton;
}

- (IBAction) startSums:(id)sender;

@end

