//
//  HotCocoaSumViewController.m
//  HotCocoaSum
//
//  Created by Antony Harris on 12/01/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "HotCocoaSumViewController.h"

@implementation HotCocoaSumViewController

- (IBAction) startSums:(id)sender
{
	int num1, num2, sum;
	
	num1 = [[num1Field text] intValue];
	num2 = [[num2Field text] intValue];
	
	sum = num1 + num2;
	
	[sumField setText:[NSString stringWithFormat:@"%i", sum]];
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
