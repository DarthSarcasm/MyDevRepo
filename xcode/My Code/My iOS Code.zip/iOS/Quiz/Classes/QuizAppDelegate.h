//
//  QuizAppDelegate.h
//  Quiz
//
//  Created by Antony Harris on 13/01/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QuizAppDelegate : NSObject <UIApplicationDelegate> {
	int currentQuestionIndex;

	// Modal objects - Arrays
	NSMutableArray *questions, *answers;
	
	// View Objects - the labels
	IBOutlet UILabel *questionField;
	IBOutlet UILabel *answerField;
	
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

// Declare methods
- (IBAction)showQuestion:(id)sender;
- (IBAction)showAnswer:(id)sender;

@end

