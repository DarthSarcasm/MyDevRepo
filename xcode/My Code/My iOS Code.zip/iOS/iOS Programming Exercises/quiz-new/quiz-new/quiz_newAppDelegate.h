//
//  quiz_newAppDelegate.h
//  quiz-new
//
//  Created by Antony Harris on 25/09/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface quiz_newAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
