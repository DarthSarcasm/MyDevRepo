//
//  RankingServiceTestAppDelegate.h
//  RankingServiceTest
//
//  Created by Damia Ferrer on 12/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RankingServiceTestViewController;

@interface RankingServiceTestAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    RankingServiceTestViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet RankingServiceTestViewController *viewController;

@end

