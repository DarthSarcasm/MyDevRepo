//
//  RankingServiceTestViewController.h
//  RankingServiceTest
//
//  Created by Damia Ferrer on 12/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RankingServiceTestViewController : UIViewController <UITextFieldDelegate> {
	
	//UI variables
	UIButton *addUserButton;
	UIButton *clearScreenButton;
	UITextView *resultServerTextView;
}

@property (nonatomic, retain) IBOutlet UIButton *addUserButton;
@property (nonatomic, retain) IBOutlet UIButton *clearScreenButton;
@property (nonatomic, retain) IBOutlet UITextView *resultServerTextView;

- (IBAction) addUserButton_TouchUpInside:(id)sender;
- (IBAction) clearScreenButton_TouchUpInside:(id)sender;

@end

