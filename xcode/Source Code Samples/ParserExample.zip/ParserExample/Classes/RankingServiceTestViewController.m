//
//  RankingServiceTestViewController.m
//  RankingServiceTest
//
//  Created by Damia Ferrer on 12/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "RankingServiceTestViewController.h"
#import "XMLParser.h"

@implementation RankingServiceTestViewController

@synthesize clearScreenButton,addUserButton,resultServerTextView;


- (IBAction) addUserButton_TouchUpInside:(id)sender{
	
	//reading the file.
	NSString *filePath = [[NSBundle mainBundle] pathForResource:@"testXML" ofType:@"xml"];  
	NSData *fileData = [NSData dataWithContentsOfFile:filePath]; 
	NSString *xmlFile = [[NSString alloc] initWithData:fileData encoding:NSASCIIStringEncoding];
	
	//parsing the XML
	XMLParser *parser = [[XMLParser alloc] init];
	[parser parseXMLFile:xmlFile];
	[xmlFile release];
	[parser print];
	
	//show results to the text view screen.
	NSString *aux = [resultServerTextView.text stringByAppendingString:[NSString stringWithFormat:@"\nHiveStudio ranking: "]];
	[resultServerTextView setText:aux];
	
	int i=1;
	for (Row* row in parser.rows) {
		NSLog(@"ROW user=%@ score =%@", row.user,row.score);
		aux = [resultServerTextView.text stringByAppendingString:[NSString stringWithFormat:@"\n   %i) %@: %@",i,row.user,row.score]];
		[resultServerTextView setText:aux];
		i++;
	}
	
	
}

- (IBAction) clearScreenButton_TouchUpInside:(id)sender{
	[resultServerTextView setText:@">"];
}


/*
 It is your application’s responsibility to dismiss the keyboard at the time of your choosing. 
 You might dismiss the keyboard in response to a specific user action, such as the user tapping a particular button 
 in your user interface. You might also configure your text field delegate to dismiss the keyboard when the user 
 presses the “return” key on the keyboard itself. 
 Called wen the user dismiss the keyboard. 
 */
- (BOOL)textFieldShouldReturn:(UITextField *)theTextField {
	[theTextField resignFirstResponder];
	[self becomeFirstResponder];
	return YES;
}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
	[addUserButton release];
	[resultServerTextView release];
}

@end
