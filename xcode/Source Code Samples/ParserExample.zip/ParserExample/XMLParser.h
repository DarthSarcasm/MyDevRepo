//
//  XMLParser.h
//  RankingServiceTest
//
//  Created by Damia Ferrer on 16/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface XMLParser : NSObject <NSXMLParserDelegate> {
	NSMutableString *currentString;
    BOOL storingCharacters;
	
	NSString *user;
	NSString *score;
	NSString *responseCode;
	
	int index;
	NSMutableArray *rows;
}

@property (nonatomic, retain) NSMutableString *currentString;
@property (nonatomic, retain) NSString *user;
@property (nonatomic, retain) NSString *score;
@property (nonatomic, retain) NSString *responseCode;
@property (nonatomic)  BOOL storingCharacters;

@property (nonatomic, retain) NSMutableArray *rows;

- (void)parseXMLFile:(NSString *)pathToFile;
- (void)print;

@end


@interface Row: NSObject{
	NSString *user;
	NSString *score;
}
@property (nonatomic, retain) NSString *user;
@property (nonatomic, retain) NSString *score;
@end
