//
//  XMLParser.m
//  RankingServiceTest
//
//  Created by Damia Ferrer on 16/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "XMLParser.h"

@implementation Row
@synthesize user,score;
- (void)dealloc {
	[user release];
	[score release];
	[super dealloc];
}
@end

@implementation XMLParser

@synthesize currentString,storingCharacters,user,score,responseCode,rows;

/*
 to parse a XML file from path. 
 */
- (void)parseXMLFile:(NSString *)data {
	BOOL success;
	
	//array for the ranking
	rows = [[NSMutableArray alloc] init];
	index = 0;
	
	self.currentString = [NSMutableString string];
	storingCharacters = NO;
    NSXMLParser *parser = [[NSXMLParser alloc] initWithData:[data dataUsingEncoding: NSUTF8StringEncoding]];
    [parser setDelegate:self];
    [parser setShouldResolveExternalEntities:YES];
    success = [parser parse];
	self.currentString = nil;
	
	//release memory
	[parser release];
}

#pragma mark NSXMLParser Parsing Callbacks

// Constants for the XML element names that will be considered during the parse. 
// Declaring these as static constants reduces the number of objects created during the run
// and is less prone to programmer error.
static NSString *kName_response = @"response";
static NSString *kName_responseCode = @"responseCode";
static NSString *kName_rows = @"rows";
static NSString *kName_row = @"row";
static NSString *kName_user = @"user";
static NSString *kName_score = @"score";

/*
 Sent by a parser object to its delegate when it encounters a start tag for a given element.
 Parameters
 parser: A parser object.
 elementName: A string that is the name of an element (in its start tag).
 namespaceURI: If namespace processing is turned on, contains the URI for the current namespace as a string object.
 qualifiedName: If namespace processing is turned on, contains the qualified name for the current namespace as a string object..
 attributeDict: A dictionary that contains any attributes associated with the element. Keys are the names of attributes, and values are attribute values.
 */
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict {
	
	if ([elementName isEqualToString:kName_response]) {
		
	}else if ([elementName isEqualToString:kName_responseCode]) {
		[currentString setString:@""];
		storingCharacters = YES;
	}else if ([elementName isEqualToString:kName_rows]) {
		
	}else if ([elementName isEqualToString:kName_row]) {
		
	}else if ([elementName isEqualToString:kName_user]) {
		[currentString setString:@""];
		storingCharacters = YES;
		
	}else if ([elementName isEqualToString:kName_score]) {
		[currentString setString:@""];
		storingCharacters = YES;
	}
}

/*
 Sent by a parser object to provide its delegate with a string representing all or part of the characters of the current element.
 Parameters
 parser: A parser object.
 string: A string representing the complete or partial textual content of the current element.
 */
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
	if (storingCharacters) [currentString appendString:string];
}


/*
 Sent by a parser object to its delegate when it encounters an end tag for a specific element.
 
 Parameters
 parser: A parser object.
 elementName: A string that is the name of an element (in its end tag).
 namespaceURI: If namespace processing is turned on, contains the URI for the current namespace as a string object.
 qName: If namespace processing is turned on, contains the qualified name for the current namespace as a string object.
 */
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
   	
	if ([elementName isEqualToString:kName_response]) {
		
	}else if ([elementName isEqualToString:kName_responseCode]) {
		self.responseCode=[[NSString alloc] initWithString: currentString];
	}else if ([elementName isEqualToString:kName_rows]) {
		
	}else if ([elementName isEqualToString:kName_row]) {
		Row *row  = [[Row alloc] init];
		row.user=self.user;
		row.score=self.score;
		[self.rows insertObject:row atIndex:index];
		index=index+1;
		[row release];
		
	}else if ([elementName isEqualToString:kName_user]) {
		self.user=[[NSString alloc] initWithString: currentString];
	}else if ([elementName isEqualToString:kName_score]) {
		self.score=[[NSString alloc] initWithString: currentString];
	}
	
	storingCharacters = NO;
}

/*
 Sent by a parser object to its delegate when it encounters a fatal error.
 Parameters
 parser: A parser object.
 parseError: An NSError object describing the parsing error that occurred.
 */
- (void)parser:(NSXMLParser *)parser parseErrorOccurred:(NSError *)parseError {
	NSString *error=[NSString stringWithFormat:@"Error %i, Description: %@, Line: %i, Column: %i", 
					 [parseError code],
					 [[parser parserError] localizedDescription], 
					 [parser lineNumber],
					 [parser columnNumber]];
	
	NSLog(@"%@",error);
}

-(void) print{
	NSLog(@"responseCode: %@",self.responseCode);
	NSLog(@"user: %@",self.user);
	NSLog(@"score: %@",self.score);
	
	for (Row* row in rows) {
		NSLog(@"ROW user=%@ score =%@", row.user,row.score);
	}
	
}

- (void)dealloc {
	[rows dealloc];
	[currentString release];
	[super dealloc];
}


@end
