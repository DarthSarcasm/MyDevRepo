

#include "Decryption.h"
#include <dlfcn.h>

#import <Cocoa/Cocoa.h>

/*
	Fairmount doesn't include any decryption functions by itself.
	It will use a decryption library installed by the user, if available.
*/

//----------------------------------------------------------------------------------
dvdcss_t (*dvdcss_open)(char *) = 0;
int (*dvdcss_close)(dvdcss_t) = 0;
int (*dvdcss_seek)(dvdcss_t, int, int) = 0;
int (*dvdcss_read)(dvdcss_t, void *, int, int) = 0;

//----------------------------------------------------------------------------------
static int LoadLib(const char *path)
{
	void *dvdcss_library = dlopen(path, RTLD_NOW);
	if (!dvdcss_library) return -1;
	
    dvdcss_open = (dvdcss_t (*)(char*))					dlsym(dvdcss_library, "dvdcss_open");
    dvdcss_close = (int (*)(dvdcss_t))					dlsym(dvdcss_library, "dvdcss_close");
    dvdcss_seek = (int (*)(dvdcss_t, int, int))			dlsym(dvdcss_library, "dvdcss_seek");
    dvdcss_read = (int (*)(dvdcss_t, void*, int, int))	dlsym(dvdcss_library, "dvdcss_read");

	if(!dvdcss_open || !dvdcss_close || !dvdcss_seek || !dvdcss_read)
	{
		dlclose(dvdcss_library);
		return -1;
	}
	
	fprintf(stderr, "loaded dvdcss from %s\n", path);
	return 0;	
}

//----------------------------------------------------------------------------------
static int ParseDirectory(NSString *path, NSFileManager *fm)
{
	BOOL isDir;
	BOOL exists = [fm fileExistsAtPath:path isDirectory:&isDir];
	
	if (!exists || !isDir) return -1;

	NSArray *a = [fm subpathsAtPath:path];
	int c = [a count], i;
	for (i = 0; i < c; i++)
	{
		NSString *cur = [path stringByAppendingPathComponent:[a objectAtIndex:i]];
		exists = [fm fileExistsAtPath:cur isDirectory:&isDir];
		if (!exists) continue;
		
		if (isDir)
		{
			int ret = ParseDirectory(cur, fm);
			if (ret == 0) return 0;
		}
		else if ([cur rangeOfString:@"dvdcss"].location != NSNotFound)
		{
			int ret = LoadLib([cur fileSystemRepresentation]);
			if (ret == 0) return 0;			
		}
	}
	
	return -1;
}

//----------------------------------------------------------------------------------
int InitDecryption(const char **vlcPath)
{
	if (vlcPath) *vlcPath = nil;

	NSString *path = [[NSWorkspace sharedWorkspace] absolutePathForAppBundleWithIdentifier:@"org.videolan.vlc"];
	if (!path) return -1;
	if (vlcPath) *vlcPath = [path UTF8String];
	
	NSFileManager *fm = [NSFileManager defaultManager];
	if (!fm) return -1;
	
	return ParseDirectory(path, fm);
}
