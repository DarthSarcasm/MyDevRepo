

#import <Cocoa/Cocoa.h>

@interface Overlay : NSWindow
{
	NSImageView *mImageView;
}
- (void) setStep:(int)step;
@end

