//
//  BFPagedContainerView.h
//  Briefs
//
//  Created by Rob Rhyne on 3/21/10.
//  Copyright Digital Arch Design, 2009-2010. See LICENSE file for details.
//

@interface BFPagedContainerView : UIView 
{
    IBOutlet UIScrollView *scrollView;
}

@end
