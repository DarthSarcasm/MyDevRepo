// 
//  BriefRef.m
//  Briefs
//
//  Created by Rob Rhyne on 3/29/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "BriefRef.h"

#import "BriefcastRef.h"

@implementation BriefRef 

@dynamic dateLastOpened;
@dynamic author;
@dynamic lastSceneOpened;
@dynamic totalNumberOfScenes;
@dynamic title;
@dynamic desc;
@dynamic dateLastDownloaded;
@dynamic fromURL;
@dynamic filePath;
@dynamic briefcast;

@end
