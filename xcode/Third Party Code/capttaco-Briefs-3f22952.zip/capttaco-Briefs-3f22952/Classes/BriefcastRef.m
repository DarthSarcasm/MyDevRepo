// 
//  BriefcastRef.m
//  Briefs
//
//  Created by Rob Rhyne on 3/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "BriefcastRef.h"

#import "BriefRef.h"

@implementation BriefcastRef 

@dynamic dateLastRefresh;
@dynamic fromURL;
@dynamic desc;
@dynamic totalNumberOfBriefcasts;
@dynamic title;
@dynamic dateLastOpened;
@dynamic briefs;

@end
